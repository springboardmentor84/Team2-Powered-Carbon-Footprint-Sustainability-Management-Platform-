package com.ecotrack.backend.controller;

import com.ecotrack.backend.dto.request.GenerateReportRequest;
import com.ecotrack.backend.dto.response.GeneratedReportResponse;
import com.ecotrack.backend.dto.response.ReportSummaryResponse;
import com.ecotrack.backend.service.interfaces.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.security.Principal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/summary")
    public ResponseEntity<ReportSummaryResponse> getSummary(
            Principal principal,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        
        ReportSummaryResponse response = reportService.getReportSummary(principal.getName(), startDate, endDate);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/carbon/csv")
    public ResponseEntity<byte[]> getCarbonCsv(
            Principal principal,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        byte[] csvBytes = reportService.generateCsvReport(principal.getName(), startDate, endDate);

        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=carbon_report.csv");
        headers.set(HttpHeaders.CONTENT_TYPE, "text/csv");

        return ResponseEntity.ok()
                .headers(headers)
                .body(csvBytes);
    }

    @GetMapping("/pdf")
    public ResponseEntity<byte[]> getPdfReport(
            Principal principal,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        byte[] pdfBytes = reportService.generatePdfReport(principal.getName(), startDate, endDate);

        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=sustainability_report.pdf");
        headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE);

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes);
    }
    @PostMapping("/generate")
    public ResponseEntity<GeneratedReportResponse> generateReport(
            Principal principal,
            @Valid @RequestBody GenerateReportRequest request) {
        GeneratedReportResponse response = reportService.generateAndSaveReport(principal.getName(), request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/history")
    public ResponseEntity<List<GeneratedReportResponse>> getReportHistory(Principal principal) {
        List<GeneratedReportResponse> history = reportService.getReportHistory(principal.getName());
        return ResponseEntity.ok(history);
    }

    @GetMapping("/{id}/download")
    public ResponseEntity<byte[]> downloadGeneratedReport(
            Principal principal,
            @PathVariable Long id) {
        
        List<GeneratedReportResponse> history = reportService.getReportHistory(principal.getName());
        GeneratedReportResponse report = history.stream().filter(r -> r.getId().equals(id)).findFirst().orElse(null);
        if (report == null) {
            return ResponseEntity.notFound().build();
        }

        byte[] fileBytes = reportService.downloadReport(principal.getName(), id);

        String safePeriod = (report.getReportPeriod() != null) ? report.getReportPeriod().replace(" ", "_") : "custom";
        String safeFormat = (report.getFormat() != null) ? report.getFormat().toLowerCase() : "pdf";
        
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ecotrack_report_" + safePeriod + "." + safeFormat);
        headers.set(HttpHeaders.CONTENT_TYPE, "CSV".equalsIgnoreCase(report.getFormat()) ? "text/csv" : MediaType.APPLICATION_PDF_VALUE);

        return ResponseEntity.ok()
                .headers(headers)
                .body(fileBytes);
    }
}
