# Upgrade Plan: ecotrack-backend (20260826043513)

- **Generated**: 2026-08-26
- **HEAD Branch**: feature/project-setup
- **HEAD Commit ID**: unavailable from precheck metadata

## Available Tools

**JDKs**
- JDK 21.0.12: C:\Program Files\Java\jdk-21.0.12\bin (current project JDK, baseline)
- JDK 25: **<TO_BE_INSTALLED>** (required for upgrade and final validation)

**Build Tools**
- Maven 3.9.16: C:\Users\HARSHIT\Downloads\apache-maven-3.9.16-bin\apache-maven-3.9.16\bin
- Maven Wrapper: 3.9.16 (already compatible; use backend\mvnw.cmd)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260826043513
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java runtime target from 21 to 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested latest LTS runtime |
| Spring Boot | 4.1.0 | 4.1.0 | Already compatible with the requested runtime target |
| Spring Boot Admin | 4.1.2 | 4.1.2 | Existing version aligns with Spring Boot 4.1 |
| Maven Wrapper | 3.9.16 | 3.9+ | Already compatible with Java 25 |
| maven-compiler-plugin | Spring Boot managed | 3.11+ recommended | Java 25 compilation should use a current plugin; managed version will be verified during build |
| Kotlin | Not used | N/A | No Kotlin source or version property detected |
| JUnit/Spring test starters | Spring Boot managed | Java 25-compatible managed versions | Test compilation and execution will verify compatibility |

## Derived Upgrades

- Set the Maven `java.version` property to `25`, which controls compiler release configuration.
- Install and use JDK 25 for upgraded compilation and tests.
- Retain Maven Wrapper 3.9.16 because it already meets the Maven 3.9+ recommendation.
- No Kotlin upgrade is required because the project does not use Kotlin.
- No Spring Boot upgrade is required because the project is already on Spring Boot 4.1.0.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| backend/pom.xml | `java.version` property | 21 | upgrade | 25 | Sets Maven compiler and runtime target to Java 25 |
| backend/.mvn/wrapper/maven-wrapper.properties | Maven Wrapper distribution | 3.9.16 | retain | 3.9.16 | Already compatible with Java 25; no meaningful wrapper change needed |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|-----------------|--------|
| None identified | N/A | No Java 25-incompatible API or internal JDK usage found in the targeted scan | None | Runtime target-only upgrade; compilation and tests provide validation |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|-----------------|--------|
| None identified | N/A | No Java-version-specific application configuration found | None | Java target is configured through Maven |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|-----------------|
| None identified | N/A | No CI/CD Java version file in the backend project scope was identified | None |

### Risks & Warnings

- **JDK 25 availability**: JDK 25 is not installed during planning. **Mitigation**: Install JDK 25 before the upgrade step; if installation fails, enter degraded mode and record that build/test verification requires manual execution.
- **Explicit dependency pins**: JJWT 0.11.5, Cloudinary 1.36.0, and OpenPDF 1.3.30 are explicit pins. **Mitigation**: Preserve them during the Java-only upgrade unless CVE validation identifies a patched version; do not remove pins without security evidence.
- **Runtime-only compatibility**: Third-party libraries may expose Java 25 runtime issues that compilation cannot detect. **Mitigation**: Run the full existing test suite and inspect failures before completion.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Make the target runtime available while preserving JDK 21 for baseline comparison.
  - **Changes to Make**: Install JDK 25 if absent; retain Maven Wrapper 3.9.16.
  - **Verification**: List JDKs and verify JDK 25 is available; use `backend\mvnw.cmd`.

- Step 2: Setup Baseline
  - **Rationale**: Establish current Java 21 compilation and test results before changing the target.
  - **Changes to Make**: No project file changes.
  - **Verification**: `mvn clean compile test-compile -q` and `mvn clean test -q` with JDK 21; record pass rate.

- Step 3: Upgrade Java Runtime Target
  - **Rationale**: Apply the requested Java 21 to Java 25 target change while keeping the existing compatible framework and build tool versions.
  - **Changes to Make**: Apply the Dependency Changes listed above to `backend/pom.xml`.
  - **Verification**: `mvn clean test-compile -q` with JDK 25; main and test sources must compile.

- Step 4: CVE Validation & Fix
  - **Rationale**: Revalidate resolved direct dependency versions after the upgrade and remediate reported vulnerabilities.
  - **Changes to Make**: Scan versioned direct dependencies; upgrade only dependencies with reported patched CVEs and update the POM as needed.
  - **Verification**: Rebuild with `mvn clean test-compile -q`, then rescan dependencies; all actionable CVEs must be resolved.

- Step 5: Final Validation
  - **Rationale**: Confirm Java 25 target, clean compilation, and 100% test pass rate.
  - **Changes to Make**: Resolve all build/test failures and remove any temporary workarounds or TODOs introduced during the upgrade.
  - **Verification**: With JDK 25 run `mvn clean test-compile -q`, `mvn clean test -q`, and `mvn clean verify -Djacoco.skip=false`; all must succeed.
