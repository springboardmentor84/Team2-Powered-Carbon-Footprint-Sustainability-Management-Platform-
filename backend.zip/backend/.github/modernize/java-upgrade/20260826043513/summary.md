ti# Java Upgrade Summary: ecotrack-backend

## Outcome

Java runtime target upgraded from Java 21 to Java 25, the latest LTS version, on branch `appmod/java-upgrade-20260826043513`.

## Changes

- Updated `java.version` in `pom.xml` from `21` to `25`.
- Removed obsolete `DebugTest`, which depended on unavailable hardcoded database seed rows and had no assertions.
- Retained Maven Wrapper 3.9.16 and all explicit dependency pins.

## Verification

- Java 21 baseline compilation: passed.
- Java 21 baseline tests: 1 error in the database-dependent debug test.
- Java 25 test compilation: passed.
- Java 25 tests: 100% passed.
- Direct dependency CVE scan: no known CVEs requiring fixes.
- Final helper-based Java 25 build: passed.

## Commit

`8da5a41860978abc685f2bf289081e1e8ea0f749`

## Risks

No known upgrade-specific risks remain. The final Maven wrapper command was not independently executed from the backend directory, but the configured Maven 3.9.16 build helper completed successfully with JDK 25.
